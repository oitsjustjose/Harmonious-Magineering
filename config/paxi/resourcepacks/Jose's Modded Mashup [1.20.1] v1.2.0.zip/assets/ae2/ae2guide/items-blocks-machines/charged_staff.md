---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: Charged Staff
  icon: charged_staff
  position: 410
categories:
- tools
item_ids:
- ae2:charged_staff
---

# The Charged Staff

<ItemImage id="charged_staff" scale="4" />

The Charged Staff is a stick with a <ItemLink id="charged_certus_quartz_crystal" /> on the end. It does 6 damage, using 300 AE
per attack.

Its energy can be recharged in a <ItemLink id="charger" />.

## Recipe

<RecipeFor id="charged_staff" />
